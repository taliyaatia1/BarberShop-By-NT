package com.example.hairstylingbynt;

public class CollectionReference {
}
